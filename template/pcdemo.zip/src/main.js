import Vue from 'vue'
import App from './App'
<<<<<<< HEAD
=======
import store from './store'
import i18n from './lang'
import 'normalize.css/normalize.css'
import AppConfig from './data/getConfig'
import config from './config'
>>>>>>> init files

Vue.config.productionTip = false

/* eslint-disable no-new */
<<<<<<< HEAD
new Vue({
  el: '#app',
})
=======
import * as filters from './filters' //引入过滤器
Object.keys(filters).forEach(key => {//注册过滤器
  Vue.filter(key,filters[key])
  })

AppConfig.getConfig().then(d=>{
  Object.assign(config.d);
  new Vue({
  el: '#app',
    })
})

>>>>>>> init files
